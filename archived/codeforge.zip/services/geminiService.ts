import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure API key is present; in a real app, handle missing key gracefully in UI
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateAIResponse = async (
  prompt: string, 
  context?: string
): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please configure your environment.";
  }

  try {
    const systemInstruction = `You are CodeForge AI, an expert software modernization assistant. 
    You help users understand legacy code, suggest refactoring strategies based on industry standard playbooks (e.g., migrating Angular to React, monolith to microservices), and explain security vulnerabilities.
    Keep your answers concise, technical, and professional. 
    
    If provided, use the following context about the user's current codebase status: ${context || 'No specific codebase context provided.'}`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I encountered an error while processing your request.";
  }
};
