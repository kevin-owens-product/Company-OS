import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Ingestion from './components/Ingestion';
import PlaybookLibrary from './components/PlaybookLibrary';
import AnalysisResults from './components/AnalysisResults';
import Transformations from './components/Transformations';
import Governance from './components/Governance';
import Settings from './components/Settings';
import AIAssistant from './components/AIAssistant';
import { Construction, Settings as SettingsIcon } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    const commonProps = { navigateTo: setActiveTab };

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard {...commonProps} />;
      case 'ingestion':
        return <Ingestion {...commonProps} />;
      case 'analysis':
        return <AnalysisResults {...commonProps} />;
      case 'playbooks':
        return <PlaybookLibrary {...commonProps} />;
      case 'transformations':
        return <Transformations {...commonProps} />;
      case 'governance':
        return <Governance {...commonProps} />;
      case 'settings':
        return <Settings {...commonProps} />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[60vh] text-slate-500">
            <Construction className="w-16 h-16 mb-4 opacity-50" />
            <h2 className="text-xl font-semibold text-slate-300">Work in Progress</h2>
            <p className="text-sm">The {activeTab} module is currently under development.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex text-slate-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 ml-64 p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-slate-400 text-sm font-medium mb-1">
              {activeTab === 'dashboard' ? 'Overview' : 
               activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h2>
            <div className="h-1 w-12 bg-blue-600 rounded-full"></div>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="px-3 py-1 bg-slate-800 rounded-full border border-slate-700 text-xs text-slate-400 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                System Operational
             </div>
             <button 
              onClick={() => setActiveTab('settings')}
              className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800"
             >
               <SettingsIcon className="w-5 h-5" />
             </button>
          </div>
        </header>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {renderContent()}
        </div>
      </main>
      
      <AIAssistant />
    </div>
  );
};

export default App;